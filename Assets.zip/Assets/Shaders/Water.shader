Shader "Aster/Water" {
 Properties { _Color ("Water",Color)=(0.05,0.42,0.42,0.9) }
 SubShader { Tags {"RenderType"="Opaque"} LOD 200
 CGPROGRAM
 #pragma surface surf Standard vertex:vert
 #pragma target 3.0
 fixed4 _Color;
 struct Input {float3 worldPos;};
 void vert(inout appdata_full v){v.vertex.y+=sin(v.vertex.x*2+_Time.y*.7)*.012+cos(v.vertex.z*2.4+_Time.y)*.009;}
 void surf(Input IN,inout SurfaceOutputStandard o){float s=sin(IN.worldPos.x*6+_Time.y)*sin(IN.worldPos.z*5-_Time.y*.8);o.Albedo=_Color.rgb+s*.024;o.Metallic=.2;o.Smoothness=.82;o.Alpha=1;}
 ENDCG
 } FallBack "Standard"
}
